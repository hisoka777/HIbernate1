package com.everis.spring.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.everis.spring.repository.EverisCustomer;
import com.everis.spring.repository.EverisCustomerRepository;
import com.everis.spring.services.EverisCustomerManagementServiceImpl;


@Controller
@RequestMapping("*")
public class EverisController {
	@Autowired
	EverisCustomerManagementServiceImpl s ;
	private final EverisCustomerRepository repository;
	
	EverisController(EverisCustomerRepository repository){
		this.repository=repository;
	}
	
	@GetMapping("/*")
	public String  showViewIndex() {
		return "systemMenu";
	}


	@GetMapping("/showCustomersView")
	public String  showAllClients(Model model) {
			final List<EverisCustomer> customersList = s.searchAllCustomers();
			
			model.addAttribute("customersList", s.searchAllCustomers());
			
			model.addAttribute("btnDropCustomerEnabled",Boolean.FALSE);
		return "showCustomers";
		 
	}
	
	@RequestMapping(value="/newCustomerView",method=RequestMethod.GET)
	public String  newCustomerView() {
		return "newCustomer";
	}
	
	
	
	@RequestMapping(value = "/actAddCustomer", method= RequestMethod.POST)	
	public String  addNewClient(@ModelAttribute EverisCustomer newCustomer) {
		
		s.insertNewCustomer(newCustomer);
		
		return "redirect:showCustomersView";	
	}
	
	@RequestMapping(value="/searchCustomerByView",method = RequestMethod.GET)
	public String  searchByname() {
		return "searchCustomerBy";	
	}
	
	
	@RequestMapping(value="/actDropCustomer" , method= RequestMethod.POST)
	public String deleteById(@RequestParam Long id ) {
		
			s.deleteCustomerById(id);
			
		return "showCustomers";
	}
	
	
}
