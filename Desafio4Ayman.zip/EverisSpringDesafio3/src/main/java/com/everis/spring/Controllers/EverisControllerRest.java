package com.everis.spring.Controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class EverisControllerRest {

	
	
}
