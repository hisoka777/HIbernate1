package com.everis.spring.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.everis.spring.repository.EverisCustomer;
import com.everis.spring.repository.EverisCustomerRepository;
import com.everis.spring.services.EverisCustomerManagementServiceImpl;

@RestController
@RequestMapping("/customer")
public class EverisController {
	@Autowired
	EverisCustomerManagementServiceImpl s;
	private final EverisCustomerRepository repository;

	EverisController(EverisCustomerRepository repository) {
		this.repository = repository;
	}

	@GetMapping()
	public List<EverisCustomer> showAllClients(Model model) {
		return s.searchAllCustomers();

	}

	@PostMapping
	public EverisCustomer newCustomerView(@RequestBody EverisCustomer newCostumer) {
		return s.insertNewCustomer(newCostumer);
	}

	@RequestMapping(path = "/{name}", method = RequestMethod.POST)
	public List<EverisCustomer> searchByname(@PathVariable String name) {

		return s.searchByName(name);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable Long id) {

		s.deleteCustomerById(id);
	}

}
