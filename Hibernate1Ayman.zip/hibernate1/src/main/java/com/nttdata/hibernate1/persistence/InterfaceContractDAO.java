package com.nttdata.hibernate1.persistence;

import java.util.List;

public interface InterfaceContractDAO {

	 public void addContract(Contract contract);
	 
	 public List<Contract> getAllContract();
	 
	 public Contract getByID(Long id);
	 
	 public void update(Contract contract);
	 
	 public void delete(Contract contract);
	 
	 public Contract searchByClientID(Long client_ID);
}
