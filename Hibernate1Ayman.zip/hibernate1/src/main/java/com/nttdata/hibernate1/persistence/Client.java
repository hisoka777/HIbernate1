package com.nttdata.hibernate1.persistence;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name = "T_Client")
public class Client implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = " Client_ID")
	private Long ClientID;

	@Column(name = "surname")
	private String surname;

	@Column(name = "firstname")
	private String firstname;

	@Column(name = "numberID", length = 9, unique = true)
	@NotNull
	private Integer numberID;
	
	
	@OneToMany(mappedBy="Client")
    private Set<Contract> contracts;
	
	
	

	public Long getClientID() {
		return ClientID;
	}

	public void setClientID(Long clientID) {
		ClientID = clientID;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public Integer getNumberID() {
		return numberID;
	}

	public void setNumberID(Integer numberID) {
		this.numberID = numberID;
	}

}
