package com.nttdata.hibernate1.persistence;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name = "T_Contract")
public class Contract implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = " Contract_ID")
	
	private Long ContractID;
	
	@Column(name = "Fecha_vigencia")
	private Date vigencia;
	
	@Column(name = "Fecha_caducidad")
	private Date caducidad;
	
	@Column(name= "Price")
	private Double price;

	public Long getContractID() {
		return ContractID;
	}

	public void setContractID(Long contractID) {
		ContractID = contractID;
	}

	public Date getVigencia() {
		return vigencia;
	}

	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}

	public Date getCaducidad() {
		return caducidad;
	}

	public void setCaducidad(Date caducidad) {
		this.caducidad = caducidad;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}
	
	
	@ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name = "Client_ID") 
	private Client client;
	
	

}
