package com.nttdata.hibernate1.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ContractImpl implements InterfaceContractDAO {
	@Autowired
	private EntityManager entityManager;

	@Override
	@Transactional
	public void addContract(Contract contract) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.save(contract);

		currentSession.close();
	}

	@Override
	public List<Contract> getAllContract() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Contract> query = currentSession.createQuery("from contract");
		List<Contract> list = query.list();
		currentSession.close();

		return list;
	}

	@Override
	public Contract getByID(Long id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Contract c = currentSession.find(Contract.class, id);

		currentSession.close();

		return c;
	}

	@Override
	public void update(Contract contract) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(contract);
		currentSession.close();

	}

	@Override
	public void delete(Contract contract) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.delete(contract);

		currentSession.close();
	}

	@Override
	public Contract searchByClientID(Long client_ID) {

		Session currentSession = entityManager.unwrap(Session.class);
		Contract c = currentSession.get(Contract.class, client_ID);
		currentSession.close();

		return c;
	}

}
