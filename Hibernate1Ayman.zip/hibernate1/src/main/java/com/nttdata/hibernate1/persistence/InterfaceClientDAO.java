package com.nttdata.hibernate1.persistence;

import java.util.List;

public interface InterfaceClientDAO {
	
	 public void addClient(Client client);
	 
	 public List<Client> getAllClient();
	 
	 public Client getByID(Long id);
	 
	 public void update(Client client);
	 
	 public void delete(Client client);
	 
	 public Client searchByFirstname(String firstname);
	 public Client searchByLastName(String lastname);

	
	 
	 

}
