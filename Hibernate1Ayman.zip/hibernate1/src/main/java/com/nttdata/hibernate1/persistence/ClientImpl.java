package com.nttdata.hibernate1.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class ClientImpl implements InterfaceClientDAO{
	
	@Autowired
	private EntityManager entityManager;
	
	
	
	
	@Override
	@Transactional
	public void addClient(Client client) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		currentSession.save(client);
		
		currentSession.close();	
		
	}




	@Override
	@Transactional
	public List<Client>   getAllClient() {

		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<Client> query=currentSession.createQuery("from client");
		List<Client> list=query.list();  		
		currentSession.close();	
		
		return list;
		
	}




	@Override
	@Transactional
	public Client getByID(Long id) {
		Session currentSession = entityManager.unwrap(Session.class);
		
		Client c = currentSession.find(Client.class, id);
		
		currentSession.close();	
		
		return c ;
	}




	@Override
	@Transactional
	public void update(Client client) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(client);
		currentSession.close();	

	}




	@Override
	@Transactional
	public void delete(Client client) {
		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.delete(client);

		currentSession.close();	

	}




	@Override
	@Transactional
	public Client searchByFirstname(String firstname) {

		
		Session currentSession = entityManager.unwrap(Session.class);
		Client c =  (Client) currentSession.get(Client.class, firstname);

		currentSession.close();	

		
		return c;
	}
	
	@Override
	@Transactional
	public Client searchByLastName(String lastname) {

		
		Session currentSession = entityManager.unwrap(Session.class);
		Client c =  (Client) currentSession.get(Client.class, lastname);

		currentSession.close();	

		
		return c;
	}




	
	

	
	

}
